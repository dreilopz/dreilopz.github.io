import pc
import time

sp = pc.serial.Serial(0, timeout=1)
uc = pc.UC(sp, pc.SYMDICT)

print 'Rotating motor'
for i in range(550, 605+1):
    uc.write_symbol(uc.sym['OCR1A_REG'], i)
    time.sleep(0.05)
