#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''cerca.py.  PC code.'''

import datetime as dt
import os
import serial
import wx

SYMDICT = {
    'OK'    :   '\x06',
    'ERROR' :   '\x0a',
    'STATUS':   '\x07',
    'START' :   '\x00',
    'ACK'   :   '\x03',
    'END'   :   '\x04',
    'READ'  :   '\x05',
    'OCR1A_REG' :   '\x01',
    'WRITE' :   '\x02'
}

class IDGen(object):
    def __init__(self, start=0):
        self.index = start-1

    @property
    def newid(self):
        while True:
            self.index += 1
            if not (self.index in range(wx.ID_LOWEST, wx.ID_HIGHEST+1)):
                break
        return self.index

class UCException(Exception):
    pass

class UC(object):
    '''UC interface object.

    605 - 550'''
    def __init__(self, port, symdict):
        self.sym = symdict

        if (port is None) or (not port.isOpen()):
            raise UCException('Serial port error')
        self.port = port
        if self.read_symbol(self.sym['STATUS']) != self.sym['OK']:
            raise UCException('UC not present or UART error')

        print 'UC object initialized.'

    def _start_communication(self):
        self.port.write(self.sym['START'])
        if self.port.read(1) != self.sym['ACK']:
            raise UCException('UC didn\'t acknowledge.')

    def _end_communication(self):
        self.port.write(self.sym['END'])
        if self.port.read(1) != self.sym['ACK']:
            raise UCException('UC didn\'t acknowledge.')

    def read_symbol(self, symbol):
        self._start_communication()
        self.port.write(self.sym['READ'])
        self.port.write(symbol)

        if symbol == self.sym['STATUS']:
            result = self.port.read(1)

        self.port.write(self.sym['ACK'])
        self._end_communication()

        return result

    def write_symbol(self, symbol, value):
        self._start_communication()
        self.port.write(self.sym['WRITE'])
        self.port.write(symbol)

        if symbol == self.sym['OCR1A_REG']:
            hvalue = value // 256
            lvalue = value - (hvalue * 256)
            self.port.write(chr(hvalue))
            if self.port.read(1) != self.sym['ACK']:
                raise UCException('UC didn\'t acknowledge.')
            self.port.write(chr(lvalue))
            if self.port.read(1) != self.sym['ACK']:
                raise UCException('UC didn\'t acknowledge.')

        self._end_communication()
        return True

class MainFrame(wx.Frame):
    def __init__(self, **args):
        self.uc = args.pop('uc')
        wx.Frame.__init__(self, **args)
        self.panel = wx.Panel(parent=self, id=idgen.newid)
        self.slider = wx.Slider(self.panel, idgen.newid, 0, 0, 100,
                pos=(20,40), size=(250, -1),
                style=(wx.SL_HORIZONTAL | wx.SL_AUTOTICKS | wx.SL_LABELS))
        self.slider.SetTickFreq(1, 1)
        self.Bind(wx.EVT_SCROLL, self.OnScroll, self.slider)
        msg = u'Mueve el slider para cambiar la posición del motor.'
        self.text = wx.StaticText(parent=self.panel, id=idgen.newid,
                label=msg, pos=(20, 20))
        self.result = wx.StaticText(parent=self.panel, id=idgen.newid,
                                    label=u'None', pos=(20, 120))

    def OnScroll(self, evt):
        percentage = self.slider.GetValue()
        result = int((-0.55) * percentage + 604)
        self.uc.write_symbol(self.uc.sym['OCR1A_REG'], result)
        self.result.SetLabel(''.join([u'OCR1A = ', unicode(result)]))

class Cerca(wx.App):
    def __init__(self, redirect=True, filename=None):
        self.project_name = u'Control simple de servomotor'
        wx.App.__init__(self, redirect, filename)

    def OnInit(self):
        print '{0}'.format(dt.datetime.now())
        print 'Application START.'

        available_ports = scan()
        print 'Available ports: {0}'.format(available_ports)

        msg = u'''\
La aplicación utilizará un puerto serial físico o virtual, que abrirá con
la siguiente configuración (8N1)
-- 9600 bauds
-- 8 bits de datos
-- No paridad
-- 1 bit stop

Puertos seriales encontrados.  Seleccione el puerto a utilizar y presione 'OK'
o presione 'Cancel' para salir.'''
        caption = u'Selección de puerto serial'
        dlg = wx.SingleChoiceDialog(None, msg, caption,
                    [i[1] for i in available_ports])
        response = dlg.ShowModal()
        if response == wx.ID_CANCEL:
            print 'Exiting application before configuring serial port.'
            dlg.Destroy()
            return False
        elif response == wx.ID_OK:
            selected_serialport = available_ports[dlg.GetSelection()][0]
        dlg.Destroy()
        print 'Selected serial port {0}'.format(selected_serialport)

        try:
            self.sp = serial.Serial(selected_serialport, timeout=1)
        except serial.SerialException as e:
            print 'Error while opening serial port: {0}'.format(e.args)
            return False

        try:
            self.uc = UC(port=self.sp, symdict=SYMDICT)
        except UCException as e:
            print 'Error while abstracting microcontroller: {0}'.format(e.args)
            return False

        self.mainframe = MainFrame(parent=None, id=idgen.newid,
                title=self.project_name,
                style=(wx.DEFAULT_FRAME_STYLE ^ (wx.RESIZE_BORDER |
                                                 wx.MINIMIZE_BOX |
                                                 wx.MAXIMIZE_BOX)),
                name='mainframe', uc=self.uc, size=(300, 200))
        self.SetTopWindow(self.mainframe)
        self.mainframe.Show()

        return True

    def OnExit(self):
        print 'Closing serial port {0}'.format(self.sp.port)
        self.sp.close()
        print 'Application END.'

def scan():
    '''scan for available ports. return a list of tuples (num, name)

    Directly copied from example from ``pyserial`` package.
    '''
    available = []
    for i in range(256):
        try:
            s = serial.Serial(i)
            available.append( (i, s.portstr))
            s.close()
        except serial.SerialException:
            pass
    return available

def main():
    global idgen
    LOG_FILENAME = 'log'
    idgen = IDGen()

    if os.path.exists(LOG_FILENAME):
        os.remove(LOG_FILENAME)

    cerca = Cerca(redirect=True, filename=LOG_FILENAME)
    cerca.MainLoop()

if __name__ == "__main__":
    main()
