#define DELAY   150.0

#define F_CPU   4000000L
#define USART_BAUDRATE 9600
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)

#include <avr/io.h>

#define STATUSLED  PB0
#define STATUSLED_CONFIG   DDRB |= _BV(DDB0)
#define STATUSLED_TOGGLE   PORTB ^= _BV(STATUSLED)
#define STATUSLED_ON       PORTB &= ~_BV(STATUSLED)
#define STATUSLED_OFF      PORTB |= _BV(STATUSLED)

#define START   '\x00'
#define ACK     '\x03'
#define OK       '\x06'
#define ERROR    '\x0a'
#define STATUS   '\x07'
#define END      '\x04'
#define READ     '\x05'
#define OCR1A_REG '\x01'
#define WRITE    '\x02'

#include <util/delay.h>
#include <avr/interrupt.h>

void ioinit(void);
unsigned char ReadUSART(void);
void WriteUSART( unsigned char byte);

ISR(USART0_RX_vect)
{
    unsigned char buffer, hvalue, lvalue;
    unsigned int integer;


    buffer = ReadUSART();  // START.
    WriteUSART(ACK);  // ACK.

    switch ( buffer = ReadUSART() ) {
        case WRITE :
            switch ( buffer = ReadUSART() ) {
                case OCR1A_REG :
                    integer = 0;
                    hvalue = ReadUSART();
                    WriteUSART(ACK);
                    lvalue = ReadUSART();
                    WriteUSART(ACK);

                    integer = (((unsigned int) hvalue) << 8);
                    integer = integer | ((unsigned int) lvalue);
                    OCR1A = integer;
                    break;

                default:
                    break;
            }
            break;

        case READ:
            switch ( buffer = ReadUSART() ) {
                case STATUS :
                    WriteUSART(OK);
                    break;

                default:
                    break;
            }
            ReadUSART(); // ACK.
            break;

        default:
            break;
    }

    buffer = ReadUSART();  // END.
    WriteUSART(ACK);
}

    unsigned char
ReadUSART(void) {
    unsigned char byte;

    while ( !(UCSR0A & _BV(RXC0)) );
    byte = UDR0;
    return byte;
}

    void
WriteUSART( unsigned char byte) {
    while ( !(UCSR0A & _BV(UDRE0)) );
    UDR0 = byte;
    while ( !(UCSR0A & _BV(TXC0)) );
    return;
}

void
ioinit (void)
{
    cli();  // disable interrupts globally.

    // UART conf. -------------------------------------------------------------
    // Don't double the USART transmission speed.
    UCSR0A &= ~_BV(U2X0);

    UCSR0B |= _BV(RXCIE0);  // RX Complete Interrupt Enable.

    // Character size in a frame the Receiver and Transmitter use.
    // UCSZ0 = 0b011, so character size is 8 bit.
    UCSR0B &= ~_BV(UCSZ02);
    UCSR0C |= _BV(UCSZ01) | _BV(UCSZ00);

    // UMSEL0 = 0b00, so USART mode of operation is Asynchronous USART
    UCSR0C &= ~(_BV(UMSEL01) | _BV(UMSEL00));

    // UPM0 = 0b00, so parity is disabled.
    UCSR0C &= ~(_BV(UPM01) | _BV(UPM00));

    // USBS0 = 0, so we use 1 stop bit.

    UBRR0L = BAUD_PRESCALE;
    UBRR0H = (BAUD_PRESCALE >> 8);

    // Turn on the transmitter and receiver.
    UCSR0B |= (_BV(RXEN0) | _BV(TXEN0));
    // ------------------------------------------------------------------------

    STATUSLED_CONFIG;

    // PWM conf ---------------------------------------------------------------
    // (COM1A = 0b10) => (Set OC1A on Compare Match when up-counting. Clear
    //          OC1A on Compare Match when down-counting.);  DDRD.DDD5 enables
    //          the pin as digital ouput.
    PORTD |= _BV(PD5);
    DDRD |= _BV(DDD5);
    TCCR1A |= (_BV(COM1A1) | _BV(COM1A0));

    // (COM1B = 0b00) => Normal port operation, OC1B disconnected.
    TCCR1A &= ~(_BV(COM1B1) | _BV(COM1B0));

    // (WGM1 = 0b1000) => (Waveform generation mode is PWM, Phase and Frequency
    //      Correct, TOP = ICR1)
    TCCR1A &= ~_BV(WGM10);
    TCCR1A &= ~_BV(WGM11);
    TCCR1B &= ~_BV(WGM12);
    TCCR1B |= _BV(WGM13);

    // (CS1 = 0b011) => Timer/Counter clock source is clk_io/64.
    TCCR1B &= ~_BV(CS12);
    TCCR1B |= (_BV(CS11) | _BV(CS10));

    // Not actually used in any PWM mode, but written to zero to ensure
    // compatibility with future devices.
    TCCR1C &= ~(_BV(FOC1A) | _BV(FOC1B));

    // This sets the PWM period.
    OCR1A = 550;

    // f_pwm = 50 Hz
    ICR1 = 625;
    // ------------------------------------------------------------------------

    sei();
}

int
main (void)
{
    ioinit ();

    for (;;) {
        STATUSLED_TOGGLE;
        _delay_ms(DELAY);
    }

    return 0;
}
