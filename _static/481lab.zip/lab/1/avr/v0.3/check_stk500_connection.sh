avrdude -F -p m164p -c stk500 -P /dev/ttyS0 -t
