#define DELAY   150.0
#define F_CPU   4000000L
#define USART_BAUDRATE 9600
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)
#define SWITCH_PORT     PORTB
#define FWD  PB5
#define REV  PB6
#define ENA  PB7
#define START       0
#define FORWARD     4
#define BACKWARD    2
#define BRAKE       6
#define TRANSITION06    6
#define TRANSITION02    2
#define TRANSITION04    4
#define TRANSITION26    26
#define TRANSITION24    24
#define TRANSITION42    42
#define TRANSITION46    46
#define TRANSITION62    62
#define TRANSITION64    64
#define OFFSET          90

#define START   '\x00'
#define ACK     '\x03'
#define OK       '\x06'
#define ERROR    '\x0a'
#define STATUS   '\x07'
#define END      '\x04'
#define READ     '\x05'
#define INPUT_SYM '\x01'
#define OCR1A_SYM '\x08'
#define WRITE    '\x02'
#define RIGHT   1
#define LEFT   0

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

void init(void);
void update_dir(void);
void update_state(unsigned char next_state);
unsigned int ADC0_value(void);
unsigned char ReadUSART(void);
void WriteUSART( unsigned char byte);

volatile unsigned int INPUT = 512;
volatile unsigned int OUTPUT = 0;
volatile unsigned char CURRENT_STATE = 0;

ISR(USART0_RX_vect)
{
    unsigned char buffer, hvalue, lvalue;
    unsigned int integer;

    buffer = ReadUSART();  // START.
    WriteUSART(ACK);  // ACK.

    switch ( buffer = ReadUSART() ) {
        case WRITE :
            switch ( buffer = ReadUSART() ) {
                case INPUT_SYM :
                    integer = 0;
                    hvalue = ReadUSART();
                    WriteUSART(ACK);
                    lvalue = ReadUSART();
                    WriteUSART(ACK);

                    integer = (((unsigned int) hvalue) << 8);
                    integer = integer | ((unsigned int) lvalue);
                    INPUT = integer;
                    break;

                case OCR1A_SYM :
                    integer = 0;
                    hvalue = ReadUSART();
                    WriteUSART(ACK);
                    lvalue = ReadUSART();
                    WriteUSART(ACK);

                    integer = (((unsigned int) hvalue) << 8);
                    integer = integer | ((unsigned int) lvalue);
                    OCR1A = integer;
                    break;

                default:
                    break;
            }
            break;

        case READ:
            switch ( buffer = ReadUSART() ) {
                case STATUS :
                    WriteUSART(OK);
                    break;

                default:
                    break;
            }
            ReadUSART(); // ACK.
            break;

        default:
            break;
    }

    ReadUSART();    // END
    WriteUSART(ACK);    // ACK
}

    unsigned char
ReadUSART(void) {
    unsigned char byte;

    while ( !(UCSR0A & _BV(RXC0)) );
    byte = UDR0;
    return byte;
}

    void
WriteUSART( unsigned char byte) {
    while ( !(UCSR0A & _BV(UDRE0)) );
    UDR0 = byte;
    while ( !(UCSR0A & _BV(TXC0)) );
    return;
}

    unsigned int
ADC0_value(void)
{
    unsigned int adc_value;

    ADCSRA |= _BV(ADEN);  // Enable ADC.
    ADCSRA |= _BV(ADSC);  // Start conversion.
    while (ADCSRA & _BV(ADSC));  // Wait for result.
    ADCSRA &= ~_BV(ADEN);  // Disable ADC.

    // Value as an ``unsigned int`` from 2 ``unsigned char``s (bytes).
    adc_value = (unsigned int) ADCL;
    adc_value |= (((unsigned int) ADCH) << 8);

    return adc_value;
}

    void
ioinit (void)
{
    cli();  // disable interrupts globally.

    // UART conf. -------------------------------------------------------------
    // Don't double the USART transmission speed.
    UCSR0A &= ~_BV(U2X0);

    UCSR0B |= _BV(RXCIE0);  // RX Complete Interrupt Enable.

    // Character size in a frame the Receiver and Transmitter use.
    // UCSZ0 = 0b011, so character size is 8 bit.
    UCSR0B &= ~_BV(UCSZ02);
    UCSR0C |= _BV(UCSZ01) | _BV(UCSZ00);

    // UMSEL0 = 0b00, so USART mode of operation is Asynchronous USART
    UCSR0C &= ~(_BV(UMSEL01) | _BV(UMSEL00));

    // UPM0 = 0b00, so parity is disabled.
    UCSR0C &= ~(_BV(UPM01) | _BV(UPM00));

    // USBS0 = 0, so we use 1 stop bit.

    UBRR0L = BAUD_PRESCALE;
    UBRR0H = (BAUD_PRESCALE >> 8);

    // Turn on the transmitter and receiver.
    UCSR0B |= (_BV(RXEN0) | _BV(TXEN0));
    // ------------------------------------------------------------------------

    // ADC conf ---------------------------------------------------------------
    // (DDA0 = 0) => (PA0 is input)
    DDRA &= ~_BV(DDA0);
    // (PA0 = 0) => (PA0 pull-up resistor off)
    PORTA &= ~_BV(PA0);

    // (REFS = 0b00) => AREF is voltage reference.
    ADMUX &= ~(_BV(REFS1) | _BV(REFS0));

    // (ADLAR = 0) => Result is right adjusted.
    ADMUX &= ~_BV(ADLAR);

    // (MUX = 0b00000) => Select ADC0/PC0 channel.
    ADMUX &= ~(_BV(MUX3) | _BV(MUX2) | _BV(MUX1) | _BV(MUX0));

    // (ADATE = 0) => Auto Trigger disabled.
    ADCSRA &= ~_BV(ADATE);

    // (ADIE = 0) => ADC Interrupt disabled.
    ADCSRA &= ~_BV(ADIE);

    // (ADPS = 0b110) => (ADC clock prescaler = 64);
    ADCSRA &= ~_BV(ADPS0);
    ADCSRA |= (_BV(ADPS2) | _BV(ADPS1));

    // Digital input buffers in ADC0 channel is disabled.
    DIDR0 |= _BV(ADC0D);
    // ------------------------------------------------------------------------

    // PWM conf ---------------------------------------------------------------
    // (COM1A = 0b10) => (Set OC1A on Compare Match when up-counting. Clear
    //          OC1A on Compare Match when down-counting.);  DDRD.DDD5 enables
    //          the pin as digital ouput.
    PORTD |= _BV(PD5);
    DDRD |= _BV(DDD5);
    TCCR1A |= (_BV(COM1A1) | _BV(COM1A0));

    // (COM1B = 0b00) => Normal port operation, OC1B disconnected.
    TCCR1A &= ~(_BV(COM1B1) | _BV(COM1B0));

    // (WGM1 = 0b1000) => (Waveform generation mode is PWM, Phase and Frequency
    //      Correct, TOP = ICR1)
    TCCR1A &= ~_BV(WGM10);
    TCCR1A &= ~_BV(WGM11);
    TCCR1B &= ~_BV(WGM12);
    TCCR1B |= _BV(WGM13);

    // (CS1 = 0b011) => Timer/Counter clock source is clk_io/64.
    TCCR1B &= ~_BV(CS12);
    TCCR1B |= (_BV(CS11) | _BV(CS10));

    // Not actually used in any PWM mode, but written to zero to ensure
    // compatibility with future devices.
    TCCR1C &= ~(_BV(FOC1A) | _BV(FOC1B));

    // This sets the PWM period.
    OCR1A = 550;

    // f_pwm = 50 Hz
    ICR1 = 625;
    // ------------------------------------------------------------------------

    sei();
}

    void
update_state(unsigned char next_state)
{
    if (      (CURRENT_STATE == START) && (next_state == BRAKE ) ) {
        // START -> BRAKE.
        PORTB |= (_BV(FWD) | _BV(REV));
    }
    else if ( (CURRENT_STATE == START) && (next_state == BACKWARD) ) {
        // START -> BACKWARD.
        PORTB |= _BV(REV);
    }
    else if ( (CURRENT_STATE == START) && (next_state == FORWARD) ) {
        // START -> FORWARD
        PORTB |= _BV(FWD);
    }
    else if ( (CURRENT_STATE == BACKWARD) && (next_state == BRAKE) ) {
        // BACKWARD -> BRAKE
        PORTB |= _BV(FWD);
    }
    else if ( (CURRENT_STATE == BACKWARD) && (next_state == FORWARD) ) {
        // BACKWARD -> BRAKE -> FORWARD
        PORTB |= _BV(FWD);
        PORTB &= ~_BV(REV);
    }
    else if ( (CURRENT_STATE == FORWARD) && (next_state == BACKWARD) ) {
        // FORWARD -> BRAKE -> BACKWARD
        PORTB |= _BV(REV);
        PORTB &= ~_BV(FWD);
    }
    else if ( (CURRENT_STATE == FORWARD) && (next_state == BRAKE) ) {
        // FORWARD -> BRAKE
        PORTB |= _BV(REV);
    }
    else if ( (CURRENT_STATE == BRAKE) && (next_state == BACKWARD) ) {
        // BRAKE -> BACKWARD
        PORTB &= ~_BV(FWD);
    }
    else if ( (CURRENT_STATE == BRAKE) && (next_state == FORWARD) ) {
        // BRAKE -> FORWARD
        PORTB &= ~_BV(REV);
    }

    CURRENT_STATE = next_state;
    return;
}

    void
update_dir(void)
{
    OUTPUT = ADC0_value();

    if ( OUTPUT > (INPUT + OFFSET) ) {
        update_state(FORWARD);
        PORTB |= _BV(PB1);
    }
    else if ( (OUTPUT + OFFSET) < INPUT ) {
        update_state(BACKWARD);
        PORTB &= ~_BV(PB1);
    }
    else {
        update_state(BRAKE);
    }
}

    int
main (void)
{
    // PORTB CONF. ------------------------------------------------------------
    // Whole PORTB as output GIO.
    DDRB = 0xff;  // FREE RUNNING.
    // ------------------------------------------------------------------------
    
    ioinit ();

    for (;;) {
        PORTB ^= _BV(PB0);
        update_dir();
        _delay_ms(5);
    }

    return 0;
}
