CONTROL_CHARACTERS = {
    0x02    :   {
        'symbol'        :   'STX',
        'description'   :   'Start of Text',
    },
    0x03    :   {
        'symbol'        :   'ETX',
        'description'   :   'End of Text',
    },
    0x06    :   {
        'symbol'        :   'ACK',
        'description'   :   'Acknowledgment',
    },
    0x15    :   {
        'symbol'        :   'NAK',
        'description'   :   'Negative Acknowledgment',
    },
}
