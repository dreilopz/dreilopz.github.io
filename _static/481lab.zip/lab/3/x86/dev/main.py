#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''Cliente de práctica 3.'''

import serial
from serial import SerialException, SerialTimeoutException

class BarebonesPortProtocolServer(object):
    def __init__(self):
        pass

    def _transfer_as_writer(self, *data):
        N = chr(len(data))

        try:
            # Stage 0
            self.port.write(self.__class__.STX)

            # Stage 1
            assert self.port.read(1) == self.__class__.ACK

            # Stage 2
            self.port.write(N)

            # Stage 3
            assert self.port.read(1) == self.__class__.ACK

            # Stage 4
            assert self.port.read(1) == N

            # Stage 5
            self.port.write(self.__class__.ACK)

            # Stage 6
            for ch in data:
                self.port.write(ch)

            # Stage 7
            assert self.port.read(1) == self.__class__.ACK

            # Stage 8
            self.port.write(self.__class__.ETX)

            # Stage 9
            assert self.port.read(1) == self.__class__.ACK

        except (SerialException, SerialTimeoutException, AssertionError):
            raise ServerException('Transmission failed')

    def _transfer_as_reader(self):
        try:
            # Stage 0
            assert self.port.read(1) == self.__class__.STX

            # Stage 1
            self.port.write(self.__class__.ACK)

            # Stage 2
            N = self.port.read(1)

            # Stage 3
            self.port.write(self.__class__.ACK)

            # Stage 4
            self.port.write(N)

            # Stage 5
            assert self.port.read(1) == self.__class__.ACK

            # Stage 6
            data = ''.join([i for i in self.port.read(size=ord(N))])

            # Stage 7
            self.port.write(self.__class__.ACK)

            # Stage 8
            assert self.port.read(1) == self.__class__.ETX

            # Stage 9
            self.port.write(self.__class__.ACK)

            return data

        except (SerialException, SerialTimeoutException, AssertionError):
            raise ServerException('Transmission failed')

    def _write_transmission(self, *data):
        self._transfer_as_writer(*data)

    def _read_transmission(self, data):
        '''Execute a read transmission.  Returns a string

        Returns:

        data:
          (str) Data read.
        '''
        # Client starts transfer.
        self._transfer_as_writer(data)
        return self._transfer_as_reader()
    pass

class ServerException(Exception):
    pass

class Server(BarebonesPortProtocolServer):
    '''Interface to server.'''

    STX = '\x02'
    ACK = '\x06'
    ETX = '\x03'

    GET_FREQUENCY_REGISTER = '\x00'
    SET_FREQUENCY_REGISTER = '\x01'

    def __init__(self, port=None):
        '''The port object must be open already.'''

        if (port is None) or (not port.isOpen()):
            raise ServerException('Serial port error')
        self.port = port

        super(Server, self).__init__()

    def get_frequency_register(self):
        data = self._read_transmission(
            self.__class__.GET_FREQUENCY_REGISTER)
        assert len(data) == 2

        frequency = 0
        frequency = (ord(data[1]) << 8) & 0xff00;
        frequency = frequency | ord(data[0])

        return frequency

    def set_frequency_register(self, frequency):
        assert isinstance(frequency, int)

        LSB = (frequency & 0x00ff)
        MSB = (frequency >> 8) & 0x00ff

        data = [self.__class__.SET_FREQUENCY_REGISTER, chr(LSB), chr(MSB)]
        data = ''.join(data)

        self._write_transmission(data)

def test():
    global server
    selected_serialport = '/dev/ttyUSB0'
    try:
        serial_port = serial.Serial(selected_serialport, timeout=1)
    except serial.SerialException as e:
        print 'Error while opening serial port: {0}'.format(e.args)
        return False

    server = Server(serial_port)

if __name__ == "__main__":
    test()
