#define DELAY   150.0
#define F_CPU   4000000L
#define USART_BAUDRATE 9600
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)

#define STX '\x02'
#define ACK '\x06'
#define ETX '\x03'
#define GET_FREQUENCY_REGISTER '\x00'
#define SET_FREQUENCY_REGISTER '\x01'

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

void init(void);
unsigned int ADC0_value(void);
unsigned char ReadUSART(void);
void WriteUSART( unsigned char byte);

ISR(USART0_RX_vect)
{
    unsigned char buffer, hvalue, lvalue, N;
    unsigned int integer;

    // Transfer as reader.
    // Stage 0
    buffer = ReadUSART();

    // Stage 1
    WriteUSART(ACK);
    
    // Stage 2
    N = ReadUSART();
    
    // Stage 3
    WriteUSART(ACK);
    
    // Stage 4
    WriteUSART(N);
   
    // Stage 5
    buffer = ReadUSART();
    
    // Stage 6
    switch ( buffer = ReadUSART() ) {
        case GET_FREQUENCY_REGISTER :
            // Stage 7
            WriteUSART(ACK);
            
            // Stage 8
            buffer = ReadUSART();
            
            // Stage 9
            WriteUSART(ACK);

            
            // Transfer as writer
            // Stage 0
            WriteUSART(STX);
            
            // Stage 1
            buffer = ReadUSART();
            
            // Stage 2
            N = 2;
            WriteUSART(N);
            
            // Stage 3
            buffer = ReadUSART();
            
            // Stage 4
            buffer = ReadUSART();
            if ( buffer != N )
                ;
            // long delay...
           
            // Stage 5
            WriteUSART(ACK);
            
            // Stage 6
            integer = OCR1A;
            lvalue = (unsigned char) (integer & 0x00ff);
            hvalue = (unsigned char) ((integer >> 8) & 0x00ff);
            WriteUSART(lvalue);
            WriteUSART(hvalue);
            
            // Stage 7
            buffer = ReadUSART();
            
            // Stage 8
            WriteUSART(ETX);
           
            // Stage 9
            buffer = ReadUSART();

            break;

        case SET_FREQUENCY_REGISTER :
            integer = 0;
            lvalue = ReadUSART();
            hvalue = ReadUSART();
            integer = (((unsigned int) hvalue) << 8);
            integer = integer | ((unsigned int) lvalue);
            OCR1A = integer;
            
            // Stage 7
            WriteUSART(ACK);
            
            // Stage 8
            buffer = ReadUSART();
            
            // Stage 9
            WriteUSART(ACK);

            break;
    
        default:
            break;
    }
}

    unsigned char
ReadUSART(void) {
    unsigned char byte;

    while ( !(UCSR0A & _BV(RXC0)) );
    byte = UDR0;
    return byte;
}

    void
WriteUSART( unsigned char byte) {
    while ( !(UCSR0A & _BV(UDRE0)) );
    UDR0 = byte;
    while ( !(UCSR0A & _BV(TXC0)) );
    return;
}

    void
ioinit (void)
{
    cli();  // disable interrupts globally.

    // UART conf. -------------------------------------------------------------
    // Don't double the USART transmission speed.
    UCSR0A &= ~_BV(U2X0);

    UCSR0B |= _BV(RXCIE0);  // RX Complete Interrupt Enable.

    // Character size in a frame the Receiver and Transmitter use.
    // UCSZ0 = 0b011, so character size is 8 bit.
    UCSR0B &= ~_BV(UCSZ02);
    UCSR0C |= _BV(UCSZ01) | _BV(UCSZ00);

    // UMSEL0 = 0b00, so USART mode of operation is Asynchronous USART
    UCSR0C &= ~(_BV(UMSEL01) | _BV(UMSEL00));

    // UPM0 = 0b00, so parity is disabled.
    UCSR0C &= ~(_BV(UPM01) | _BV(UPM00));

    // USBS0 = 0, so we use 1 stop bit.

    UBRR0L = BAUD_PRESCALE;
    UBRR0H = (BAUD_PRESCALE >> 8);

    // Turn on the transmitter and receiver.
    UCSR0B |= (_BV(RXEN0) | _BV(TXEN0));
    // ------------------------------------------------------------------------

    // PWM conf ---------------------------------------------------------------
    // (COM1A = 0b10) => (Set OC1A on Compare Match when up-counting. Clear
    //          OC1A on Compare Match when down-counting.);  DDRD.DDD5 enables
    //          the pin as digital ouput.
    PORTD |= _BV(PD5);
    DDRD |= _BV(DDD5);
    TCCR1A |= (_BV(COM1A1) | _BV(COM1A0));

    // (COM1B = 0b00) => Normal port operation, OC1B disconnected.
    TCCR1A &= ~(_BV(COM1B1) | _BV(COM1B0));

    // (WGM1 = 0b1000) => (Waveform generation mode is PWM, Phase and Frequency
    //      Correct, TOP = ICR1)
    TCCR1A &= ~_BV(WGM10);
    TCCR1A &= ~_BV(WGM11);
    TCCR1B &= ~_BV(WGM12);
    TCCR1B |= _BV(WGM13);

    // (CS1 = 0b011) => Timer/Counter clock source is clk_io/64.
    TCCR1B &= ~_BV(CS12);
    TCCR1B |= (_BV(CS11) | _BV(CS10));

    // Not actually used in any PWM mode, but written to zero to ensure
    // compatibility with future devices.
    TCCR1C &= ~(_BV(FOC1A) | _BV(FOC1B));

    // This sets the PWM period.
    OCR1A = 594;

    // f_pwm = 50 Hz
    ICR1 = 625;
    // ------------------------------------------------------------------------

    sei();
}

    int
main (void)
{
    ioinit ();

    for (;;) {
        PORTB ^= _BV(PB0);
        _delay_ms(5);
    }

    return 0;
}
